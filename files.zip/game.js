const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");
const statusText = document.getElementById("statusText");

const GAME_WIDTH = 420;
const GAME_HEIGHT = 640;
canvas.width = GAME_WIDTH;
canvas.height = GAME_HEIGHT;

const STATES = {
    READY: "ready",
    PLAYING: "playing",
    GAME_OVER: "game_over"
};

let pipes = [];
let score = 0;
let bestScore = Number(localStorage.getItem("jt_best_score") || 0);
let frame = 0;
let state = STATES.READY;

const bird = {
    x: 86,
    y: 250,
    width: 40,
    height: 30,
    gravity: 0.46,
    lift: -8.4,
    maxFall: 10,
    velocity: 0
};

// Bird photo
const birdImage = new Image();
let birdReady = false;
birdImage.src = "tarun.jpeg";
birdImage.onload = () => { birdReady = true; };

const bgImage = new Image();
let bgReady = false;
const imageCandidates = ["intro.jpg", "intro.jpg.jpeg"];
let imageIndex = 0;

function tryLoadBackground() {
    if (imageIndex >= imageCandidates.length) {
        return;
    }
    bgImage.src = imageCandidates[imageIndex];
}

bgImage.onload = () => {
    bgReady = true;
};

bgImage.onerror = () => {
    imageIndex += 1;
    tryLoadBackground();
};

tryLoadBackground();

function resetRun() {
    pipes = [];
    score = 0;
    frame = 0;
    bird.y = 250;
    bird.velocity = 0;
}

function flap() {
    if (state === STATES.READY) {
        resetRun();
        state = STATES.PLAYING;
        statusText.textContent = "Live";
        bird.velocity = bird.lift;
    } else if (state === STATES.PLAYING) {
        bird.velocity = bird.lift;
    } else {
        resetRun();
        state = STATES.PLAYING;
        statusText.textContent = "Live";
        bird.velocity = bird.lift;
    }
}

document.addEventListener("keydown", (event) => {
    if (event.code === "Space" || event.code === "ArrowUp" || event.code === "Enter") {
        event.preventDefault();
        flap();
    }
});

canvas.addEventListener("pointerdown", flap);

function drawCoverImage(image, x, y, width, height) {
    const imgRatio = image.width / image.height;
    const canvasRatio = width / height;
    let drawWidth = width;
    let drawHeight = height;
    let drawX = x;
    let drawY = y;

    if (imgRatio > canvasRatio) {
        drawWidth = height * imgRatio;
        drawX = x - (drawWidth - width) / 2;
    } else {
        drawHeight = width / imgRatio;
        drawY = y - (drawHeight - height) / 2;
    }

    ctx.drawImage(image, drawX, drawY, drawWidth, drawHeight);
}

function drawBackground() {
    if (bgReady) {
        drawCoverImage(bgImage, 0, 0, canvas.width, canvas.height);
        ctx.fillStyle = "rgba(9, 22, 35, 0.34)";
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        return;
    }

    const sky = ctx.createLinearGradient(0, 0, 0, canvas.height);
    sky.addColorStop(0, "#95d7ff");
    sky.addColorStop(1, "#d7f0ff");
    ctx.fillStyle = sky;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
}

function drawBird() {
    ctx.save();
    ctx.translate(bird.x + bird.width / 2, bird.y + bird.height / 2);
    const tilt = Math.max(-0.5, Math.min(1, bird.velocity / 14));
    ctx.rotate(tilt);

    const size = 52;

    if (birdReady) {
        ctx.beginPath();
        ctx.arc(0, 0, size / 2, 0, Math.PI * 2);
        ctx.clip();
        ctx.drawImage(birdImage, -size / 2, -size / 2, size, size);
    } else {
        const body = ctx.createLinearGradient(-20, -10, 20, 20);
        body.addColorStop(0, "#ffe066");
        body.addColorStop(1, "#ffbf00");
        ctx.fillStyle = body;
        ctx.beginPath();
        ctx.ellipse(0, 0, bird.width / 2, bird.height / 2, 0, 0, Math.PI * 2);
        ctx.fill();
    }

    ctx.restore();
}

function drawPipes() {
    pipes.forEach(pipe => {
        const gradient = ctx.createLinearGradient(pipe.x, 0, pipe.x + pipe.width, 0);
        gradient.addColorStop(0, "#5abf5a");
        gradient.addColorStop(1, "#2d8f2d");
        ctx.fillStyle = gradient;
        ctx.fillRect(pipe.x, 0, pipe.width, pipe.top);
        ctx.fillRect(pipe.x, pipe.bottom, pipe.width, canvas.height);

        ctx.fillStyle = "#267a26";
        ctx.fillRect(pipe.x - 4, pipe.top - 16, pipe.width + 8, 16);
        ctx.fillRect(pipe.x - 4, pipe.bottom, pipe.width + 8, 16);
    });
}

function spawnPipe() {
    const minTop = 90;
    const maxTop = canvas.height - 260;
    const top = Math.random() * (maxTop - minTop) + minTop;
    const gap = 165;
    pipes.push({
        x: canvas.width + 10,
        width: 62,
        top,
        bottom: top + gap,
        passed: false
    });
}

function endGame() {
    state = STATES.GAME_OVER;
    statusText.textContent = "Crashed";
    bestScore = Math.max(bestScore, score);
    localStorage.setItem("jt_best_score", String(bestScore));
}

function updateGame() {
    bird.velocity += bird.gravity;
    bird.velocity = Math.min(bird.velocity, bird.maxFall);
    bird.y += bird.velocity;

    if (frame % 95 === 0) {
        spawnPipe();
    }

    for (const pipe of pipes) {
        pipe.x -= 2;

        if (
            bird.x < pipe.x + pipe.width &&
            bird.x + bird.width > pipe.x &&
            (bird.y < pipe.top || bird.y + bird.height > pipe.bottom)
        ) {
            endGame();
        }

        if (!pipe.passed && pipe.x + pipe.width < bird.x) {
            pipe.passed = true;
            score += 1;
        }
    }

    pipes = pipes.filter((pipe) => pipe.x + pipe.width > -20);

    if (bird.y + bird.height > canvas.height) {
        bird.y = canvas.height - bird.height;
        endGame();
    }

    if (bird.y < 0) {
        bird.y = 0;
        bird.velocity = 0;
    }
}

function drawScore() {
    ctx.fillStyle = "rgba(3, 9, 19, 0.46)";
    ctx.fillRect(12, 12, 180, 60);
    ctx.strokeStyle = "rgba(255, 255, 255, 0.24)";
    ctx.strokeRect(12, 12, 180, 60);

    ctx.fillStyle = "#ffffff";
    ctx.font = "700 20px Trebuchet MS";
    ctx.fillText(`Score: ${score}`, 24, 36);
    ctx.font = "700 14px Trebuchet MS";
    ctx.fillStyle = "#cfe6ff";
    ctx.fillText(`Best: ${bestScore}`, 24, 57);
}

function drawOverlay() {
    if (state === STATES.PLAYING) {
        return;
    }

    ctx.fillStyle = "rgba(0, 0, 0, 0.5)";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    const cardW = 320;
    const cardH = state === STATES.READY ? 170 : 200;
    const cardX = (canvas.width - cardW) / 2;
    const cardY = (canvas.height - cardH) / 2;
    ctx.fillStyle = "rgba(8, 18, 30, 0.84)";
    ctx.fillRect(cardX, cardY, cardW, cardH);
    ctx.strokeStyle = "rgba(255, 255, 255, 0.25)";
    ctx.strokeRect(cardX, cardY, cardW, cardH);

    ctx.fillStyle = "#ffffff";
    ctx.textAlign = "center";
    ctx.font = "700 34px Trebuchet MS";

    if (state === STATES.READY) {
        ctx.fillText("Get Ready", canvas.width / 2, canvas.height / 2 - 22);
        ctx.font = "700 15px Trebuchet MS";
        ctx.fillStyle = "#cae2ff";
        ctx.fillText("PRESS SPACE OR TAP TO FLY", canvas.width / 2, canvas.height / 2 + 8);
        ctx.fillStyle = "#ffffff";
        ctx.font = "700 17px Trebuchet MS";
        ctx.fillText("Avoid Pipes. Beat Best.", canvas.width / 2, canvas.height / 2 + 36);
    } else {
        ctx.fillText("Game Over", canvas.width / 2, canvas.height / 2 - 35);
        ctx.font = "700 22px Trebuchet MS";
        ctx.fillText(`Score: ${score}`, canvas.width / 2, canvas.height / 2 + 0);
        ctx.fillStyle = "#cfe6ff";
        ctx.fillText(`Best: ${bestScore}`, canvas.width / 2, canvas.height / 2 + 34);
        ctx.fillStyle = "#ffffff";
        ctx.font = "700 15px Trebuchet MS";
        ctx.fillText("TAP OR PRESS SPACE TO RESTART", canvas.width / 2, canvas.height / 2 + 66);
    }
    ctx.textAlign = "start";
}

function gameLoop() {
    drawBackground();

    if (state === STATES.PLAYING) {
        updateGame();
        frame += 1;
    } else if (state === STATES.READY) {
        bird.y += Math.sin(Date.now() / 180) * 0.35;
    }

    drawBird();
    drawPipes();
    drawScore();
    drawOverlay();

    requestAnimationFrame(gameLoop);
}

gameLoop();
